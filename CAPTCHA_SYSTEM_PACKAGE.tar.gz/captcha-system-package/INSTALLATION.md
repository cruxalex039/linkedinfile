# CAPTCHA System Installation Guide

## Prerequisites

- Node.js 18 or higher
- Express.js 4.x application
- express-session middleware installed

## Installation Steps

### 1. Extract Package

```bash
tar -xzf captcha-system-package_*.tar.gz
cd captcha-system-package
```

### 2. Install Dependencies (if not already installed)

```bash
npm install express express-session
```

### 3. Copy Files to Your Project

#### Frontend Assets
```bash
# Copy to your project's public directory
cp -r public/js /path/to/your/project/public/
cp -r public/css /path/to/your/project/public/
```

#### Backend Routes
```bash
# Copy to your project's routes directory
cp routes/captcha.js /path/to/your/project/routes/
```

#### Views (Optional)
```bash
# Copy HTML templates
cp views/index.html /path/to/your/project/views/
cp views/recaptcha-challenge.html /path/to/your/project/views/
```

### 4. Configure Your Express Application

Add to your main server file (e.g., `server.js` or `app.js`):

```javascript
const express = require('express');
const session = require('express-session');

const app = express();

// Middleware
app.use(express.json());
app.use(express.static('public'));

// Session middleware (required)
app.use(session({
  secret: process.env.SESSION_SECRET || 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: process.env.NODE_ENV === 'production' }
}));

// Mount CAPTCHA routes
const captchaRoutes = require('./routes/captcha');
app.use('/api/captcha', captchaRoutes);

// Serve main page with CAPTCHA
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/views/index.html');
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});
```

### 5. Configure HTML Pages

Ensure your HTML files reference the correct paths:

```html
<!-- In your HTML head -->
<link href="/css/challenge.css" rel="stylesheet">
<script src="https://js.hcaptcha.com/1/api.js" async defer></script>
<script src="/js/captcha.js"></script>
```

### 6. Update hCaptcha/reCAPTCHA Site Key

Edit `views/index.html` and set your CAPTCHA site key:

```html
<!-- For hCaptcha -->
<div class="h-captcha" 
     data-sitekey="YOUR_HCAPTCHA_SITE_KEY"
     data-callback="onCaptchaSuccess"></div>

<!-- For reCAPTCHA -->
<div class="g-recaptcha" 
     data-sitekey="YOUR_RECAPTCHA_SITE_KEY"
     data-callback="onRecaptchaSuccess"></div>
```

### 7. Test Installation

```bash
# Start your server
node server.js

# Visit in browser
open http://localhost:3000
```

You should see the CAPTCHA widget. Complete it to test the full flow.

## Verification

Test the following:

1. ✅ Page loads with CAPTCHA widget
2. ✅ Complete CAPTCHA successfully
3. ✅ Check browser console for "[CAPTCHA] Token stored"
4. ✅ Check localStorage for token: `localStorage.getItem('captcha_ack_token')`
5. ✅ Verify auto-redirect after success

## API Testing

Test the API endpoints:

```bash
# Test token generation
curl -X POST http://localhost:3000/api/captcha/verify \
  -H "Content-Type: application/json" \
  -d '{"captchaResponse":"test_token"}'

# Test token validation
curl -X POST http://localhost:3000/api/captcha/validate-token \
  -H "Content-Type: application/json" \
  -d '{"token":"ack_1234567890_abc123"}'
```

## Environment Variables

Recommended environment variables:

```bash
# .env file
NODE_ENV=production
SESSION_SECRET=your-random-secret-key-here
PORT=3000
```

## Protected Routes Example

Add CAPTCHA verification to protected routes:

```javascript
// Middleware to check CAPTCHA
const requireCaptcha = (req, res, next) => {
  if (!req.session.captchaVerified) {
    return res.redirect('/');
  }
  next();
};

// Protected route
app.get('/login.html', requireCaptcha, (req, res) => {
  res.sendFile(__dirname + '/views/login.html');
});
```

## Troubleshooting

### CAPTCHA Widget Not Loading
- Check console for JavaScript errors
- Verify site key is correct
- Ensure CAPTCHA script is loading (check network tab)

### Token Not Storing
- Check browser localStorage is enabled
- Verify `/api/captcha/verify` returns token
- Check browser console for errors

### API Endpoints Not Working
- Verify routes are mounted: `app.use('/api/captcha', captchaRoutes)`
- Check express.json() middleware is configured
- Verify session middleware is configured

## Production Deployment

For production:

1. **Use HTTPS** - CAPTCHA requires secure connection
2. **Set secure cookies** - `cookie: { secure: true }`
3. **Add rate limiting** - Prevent abuse
4. **Use Redis** - For multi-server token storage
5. **Enable logging** - Monitor token usage

## Next Steps

1. Read `docs/CAPTCHA_INTEGRATION.md` for complete API documentation
2. Review `docs/SECURITY_SUMMARY.md` for security best practices
3. Check `docs/QUICK_REFERENCE.md` for common usage patterns

## Support

For issues:
1. Check documentation in `/docs/` directory
2. Review troubleshooting section above
3. Verify all prerequisites are met

---

**Need Help?** Refer to the comprehensive documentation in the `/docs/` directory.
